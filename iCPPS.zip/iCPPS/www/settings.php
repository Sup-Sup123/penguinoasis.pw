<?php
  define('MYSQL_HOSTNAME', 'ftp.wondersofdisney.info');
  define('MYSQL_USERNAME', 'wonderso_ap');
  define('MYSQL_PASSWORD', 'goahead999');
  define('MYSQL_DATABASE', 'wonderso_ap');
  define('PUFFLE_MINLEN', 1); //... Find out the real Value? ...//
  define('PUFFLE_MAXLEN', 12);
  define('PUFFLE_CHARS',  'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!?(){}[]<>.:-_ ');
  
  define('PLAYER_MINLEN', 3);
  define('PLAYER_MAXLEN', 12);
  define('PLAYER_CHARS',  'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-:*/\\!?(){}[]<>.:-_ ');
  
  define('PASSWORD_MINLEN', 6);
  define('PASSWORD_MAXLEN', 32);

  define('EMAIL_MINLEN', 6); //1@3.56
  define('EMAIL_MAXLEN', 128);
  define('EMAIL_CHARS',  'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-@');
  ?>