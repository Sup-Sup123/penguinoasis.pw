<strong>Oops! Somebody was faster than you!</strong><br />
It seems like meanwhile your Regristration somebody else always registred that PlayerName.<br />
Don't worry! You can still pick another one! Just click the "Register" Button again and<br />
change the PlayerName!<br />
The other Data was not changed :)