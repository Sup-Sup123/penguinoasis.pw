<strong>Database Errors</strong><br />
The MySQL API of PHP could not connect to the MySQL Host.<br />
The Problem will be attempted to be fixed ASAP.<br />
Much Apologies :(
<!--<?= mysql_error() ?>-->

<?php updateStatus('ui-state-highlight', '<strong>Task Failed:</strong> The Database is inaccessible!'); ?>