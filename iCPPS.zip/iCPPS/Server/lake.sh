#echo "You should run this script via this command: nohup ./main.sh &"
while [ 1 ]; do php lake.php; done
