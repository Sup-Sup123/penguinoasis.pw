<?php
$config["ADDRESS"] = 0;//Address to listen on. Use 0 for all
$config["PORT"] = 9875;
$config["max_clients"] = 500;
$config["DEBUG"] = true;
$config["RAW_STR"] = true;
$config["RAW_SEPERATOR"] = "%";
$config["MAX_CLIENTS"] = 500;
$config["USE_SEND_HANDLER"] = true; //Uses
$config["SEND_HANDLER"] = "s";
$config["MAX_IN_ROOM"] = 70;
?>
