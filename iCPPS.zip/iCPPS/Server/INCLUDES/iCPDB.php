<?php
define("DB_HOST",	"localhost");
define("DB_USER",	"Clubpenguin");
define("DB_PASS",	"3ebp5SUJrxxnM4f7");
define("DB_NAME",	"iCP");
?>