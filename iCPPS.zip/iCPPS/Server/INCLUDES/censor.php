<?php
$censored = array("fuck", "cunt");

?>
