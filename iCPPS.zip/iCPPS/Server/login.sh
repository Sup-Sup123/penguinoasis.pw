while [ 1 ]; do php login.php; done
