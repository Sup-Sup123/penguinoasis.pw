k="php ${1}.php"
while [ 1 ]; do $k; done
